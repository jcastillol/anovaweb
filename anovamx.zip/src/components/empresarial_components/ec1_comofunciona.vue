<template>
     <div class="container text-center"   style="max-width:1000px;">
      <h5  id="titulob2">¿CÓMO ES QUE</h5>
    <h5  id="tituloa2">FUNCIONA? </h5>
<br>
<br>
      <img src="img/empresarial/empresarial_diagrama.png" class=" card-img " style="max-width:686px" >



</div>

</template>
<script>
export default {
    name:'ec1_comofunciona'
}
</script>

