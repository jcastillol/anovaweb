<template>
     <div class="container text-center"   style="max-width:1000px;">
      <h5  id="titulob2">MÓDULO</h5>
    <h5  id="tituloa2">VENTAS </h5>
<br>
<br>
      <img src="img/empresarial/empresarial_iconoventas.png"  class=" mx-auto">
     
<br>
<br>
<br>

<p class="tituloc">
    Conoce la centralización de ventas entre sucursales, cancelaciones y descuentos, análisis de ventas de productos y 
promociones, base de datos única de clientes, y la segmentación de clientes, además realiza email marketing.
</p>
<br>
<br>

     <div class="container text-center"   >

<div class="row row-cols-2 row-cols-md-3 bg-transparent no-gutters  justify-content-center" >
    <div class="col ">
      <div class="card  border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoventas1.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Pago de  <br> regalías y cuotas</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoventas2.png" alt="..." class="mb-1  card-img iconoempresarial" >
          <p id="titulol">CRM</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoventas3.png" alt="..." class="mb-1  card-img iconoempresarial" >
          <p id="titulol">Reporte de ventas multisucursales <br> </p>        </div>
      </div>
    </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoventas4.png" alt="..." class="mb-1  card-img iconoempresarial" >
          <p id="titulol">Punto
de venta</p>        </div>
      </div>
      </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoventas5.png" alt="..." class="mb-1  card-img iconoempresarial" >
          <p id="titulol">Lista de precios
por sucursal</p>        </div>
      </div>
      </div>   

    
    </div>


 
     </div>



</div>


</template>
<script>
export default {
    name:'ec2_ventas'
}
</script>


