<template>
    <div class="container text-center"   style="max-width:1000px;">
      <h5  id="titulob2">MÓDULO</h5>
    <h5  id="tituloa2">FINANZAS </h5>
<br>
<br>
      <img src="img/empresarial/empresarial_iconofinanzas.png" class=" mx-auto"  >
     
<br>
<br>
<br>

<p class="tituloc">
    Observa estados financieros, centraliza tus cuentas por pagar, base de datos única de proveedores, ordenes de compra 
basadas en consumos, cumple con regulaciones fiscales y ten bajo control el manejo de bancos.
</p>
<br>
<br>

     <div class="container text-center"   >

<div class="row row-cols-2 row-cols-md-4 bg-transparent no-gutters justify-content-center " >
    <div class="col ">
      <div class="card bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconofinanzas1.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Contabilidad Electrónica</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconofinanzas2.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Estados financieros</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconofinanzas3.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Facturación CFDI 3.3
y autofacturación</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconofinanzas4.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Control de gastos</p>        </div>
      </div>
    </div>
    <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconofinanzas5.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Gestión de compras</p>       
        </div>
      </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconofinanzas6.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Gestión de activo fijo</p>        
        </div>
      </div>
      </div>
        <div class="col ">
      <div class="card bg-transparent border-0 ">
        <div class="card-body">
          <img src="img/empresarial/empresarial_iconofinanzas7.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Gestión de bancos
          </p>        
        </div>
      </div>
      </div> 
    </div>
 

 
     </div>



</div>

</template>
<script>
export default {
    name:'ec3_finanzas'
}
</script>
