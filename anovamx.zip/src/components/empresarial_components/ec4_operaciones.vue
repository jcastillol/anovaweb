<template>
    <div class="container text-center"   style="max-width:1000px;">
      <h5  id="titulob2">MÓDULO</h5>
    <h5  id="tituloa2">OPERACIONES </h5>
<br>
<br>
      <img src="img/empresarial/empresarial_iconooperaciones.png"  class=" mx-auto" >
     
<br>
<br>
<br>

<p class="tituloc">
 Supervisa desde recetas hasta la distribución en puntos de venta, además <br>
aumenta la productividad y control de tus procesos.
</p>
<br>
<br>

     <div class="container text-center"   >

<div class="row row-cols-2 row-cols-md-3 bg-transparent no-gutters justify-content-center" >
    <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconooperaciones1.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Producción y control de materia prima</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconooperaciones2.png" alt="..." class="mb-1 card-img iconoempresarial " >
          <p id="titulol">Control de inventarios en corporativo y  sucursales</p>       
      </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconooperaciones3.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Gestión global de menús y recetas</p>       
        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconooperaciones4.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Calendario Google</p>       
        </div>
      </div>
    </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconooperaciones5.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Integración con Google Drive</p>        
        </div>
      </div>
      </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconooperaciones6.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Mantenimiento de instalaciones y equipamiento
          </p>        
        </div>
      </div>
      </div>   
    
    </div>
     


 
     </div>



</div>

</template>
<script>
export default {
    name:'ec4_operaciones'
}
</script>
