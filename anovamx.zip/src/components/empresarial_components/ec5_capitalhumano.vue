<template>
    <div class="container text-center"   style="max-width:1000px;">
      <h5  id="titulob2">MÓDULO</h5>
    <h5  id="tituloa2">CAPITAL HUMANO </h5>
<br>
<br>
      <img src="img/empresarial/empresarial_iconocapitalhumano.png" class="mx-auto card-img" style="max-width:427px">
     
<br>

<br>
<br>

<p class="tituloc">
 Lleva un seguimiento completo y preciso de todos tus empleados, tanto de <br>
tus múltiples sucursales como de tu corporativo.
</p>
<br>
<br>

     <div class="container text-center"   >

<div class="row row-cols-2 row-cols-md-3 bg-transparent no-gutters justify-content-center" >
    <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano1.png" alt="..." class="mb-1 card-img  iconoempresarial" >
          <p id="titulol">Expedientes de empleados</p>       
         </div>
      </div>
    </div>
    <div class="col ">
      <div class="card bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano2.png" alt="..." class="mb-1 card-img  iconoempresarial" >
          <p id="titulol">Gestión de contratos</p>       
      </div>
      </div>
    </div>
    <div class="col ">
      <div class="card bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano3.png" alt="..." class="mb-1 card-img  iconoempresarial" >
          <p id="titulol">Gestión de permisos y vacaciones</p>       
        </div>
      </div>
    </div>
   <div class="col ">
      <div class="card bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano4.png" alt="..." class="mb-1 card-img iconoempresarial"  >
          <p id="titulol">Proceso de reclutamiento</p>       
      </div>
      </div>
    </div>
    <div class="col ">
      <div class="card bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano5.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Evaluación y valoración</p>        
        </div>
      </div>
    </div>
       <div class="col ">
      <div class="card bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano6.png" alt="..." class="mb-1 card-img iconoempresarial " >
          <p id="titulol">Control de asistencias</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano7.png" alt="..." class="mb-1  card-img iconoempresarial" >
          <p id="titulol">Horarios de empleados</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body">
          <img src="img/empresarial/empresarial_iconocapitalhumano8.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Nómina timbrada</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconocapitalhumano9.png" alt="..." class="mb-1  card-img iconoempresarial" >
          <p id="titulol">Premios y distinciones</p>        
        </div>
      </div>
    </div>
    </div>



    

     </div>


</div>

</template>
<script>
export default {
    name:'ec5_capitalhumano'
}
</script>
