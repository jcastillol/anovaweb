<template>
     <div class="container text-center"   style="max-width:1000px;">
      <h5  id="titulob2">MÓDULO</h5>
    <h5  id="tituloa2">AUDITORÍA E INSPECCIÓN </h5>
<br>
<br>
      <img src="img/empresarial/empresarial_iconoaudotoria.png"  class=" mx-auto">
     
<br>
<br>
<br>

<p class="tituloc">
Asegura la calidad y consistencia de tu marca en todas las franquicias y/o sucursales<br>
a través de la evaluación y seguimiento de los puntos clave que deben cumplirse.
</p>
<br>
<br>

     <div class="container text-center"   >

<div class="row row-cols-2 row-cols-md-3 bg-transparent no-gutters justify-content-center" >
    <div class="col ">
      <div class="card bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoaudotoria1.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Auditoría de calidad</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card bg-transparent border-0">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoaudotoria2.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Auditoría de  procesos</p>        </div>
      </div>
    </div>
      <div class="col ">
      <div class="card bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoaudotoria3.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol"> Auditoría de servicios   </p>       
        </div>
      </div>
    </div>
      <div class="col ">
      <div class="card bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoaudotoria4.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Solicitud de mantenimiento</p>        
       </div>
      </div>
      </div>
      <div class="col ">
      <div class="card bg-transparent border-0 ">
        <div class="card-body ">
          <img src="img/empresarial/empresarial_iconoaudotoria5.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Checklist de actividades diarias</p>       
        </div>
      </div>
      </div>   
    
    </div>
   



     </div>



</div>


</template>
<script>
export default {
    name:'ec6_auditoria'
}
</script>


