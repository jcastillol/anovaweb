<template>
     <div class="container text-center"   style="max-width:1000px;">
      <h5  id="titulob2">MÓDULO</h5>
    <h5  id="tituloa2">GESTIÓN DE PROYECTOS <br>
         DE NUEVAS APERTURAS</h5>
<br>
<br>
      <img src="img/empresarial/empresarial_iconogestion.png"  class=" mx-auto" >
     
<br>
<br>
<br>

<p class="tituloc">
   Planifica las actividades y recursos, da seguimiento a las tareas y personas involucradas, <br>
minimiza los riesgos elaborando presupuestos para la  remodelación o apertura de una nueva sucursal.
</p>
<br>
<br>

     <div class="container text-center"   >

<div class="row row-cols-2 row-cols-md-3 bg-transparent no-gutters justify-content-center" >
    <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body">
          <img src="img/empresarial/empresarial_iconogestion1.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Calendario de actividades</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card  bg-transparent border-0">
        <div class="card-body">
          <img src="img/empresarial/empresarial_iconogestion2.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Asignación de tareas por perfil</p>       
        </div>
      </div>
    </div>
        <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body">
          <img src="img/empresarial/empresarial_iconogestion3.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Gestión de presupuestos</p>        
        </div>
      </div>
    </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body">
          <img src="img/empresarial/empresarial_iconogestion4.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Lista de compras</p>        
        </div>
      </div>
      </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body">
          <img src="img/empresarial/empresarial_iconogestion5.png" alt="..." class="mb-1 card-img iconoempresarial" >
          <p id="titulol">Gestión de documentos Google Drive</p>       
       </div>
      </div>
      </div>  
    </div>
    


 
     </div>



</div>


</template>
<script>
export default {
    name:'ec2_ventas'
}
</script>


