<template>
    
    <div class="container mt-4 text-center" style="max-width:1200px;">
  <p  id="tituloe">Centraliza y controla la información<br>
de tu corporativo y sucursales</p>
  <br>
            <button class="button button2 ml-2">Solicitar Cotización</button>

 
</div>
</template>
<script>
export default {
    name: 'ec8_cotizacion'
}
</script>