<template>

<div class="container-fluid" id="empresarialheader">
 <div class="card mb-3 mx-auto bg-transparent border-0  "  style="max-width:1366px">
  <div class="row no-gutters">
   <div class="col-lg-6  mt-4 nomovil">
        <img src="img/empresarial/header.png"  class=" card-img " >
    </div>
    <div class="col-lg-6">
      <div class="card-body  text-center text-lg-right bg-transparent ">
               <h5   id="titulohome">ANOVA EMPRESARIAL</h5>
                <br>
   <h5  id="parrafoc">
        <img src="img/play.png" >
        Es la solución integral para franquicias y cadenas con <br>
             visón general de tu corporativo y sucursales,<br>
    modular, flexible y fácilmente escalable; <br>
      todo en un solo sistema y en tiempo real.

  <br>

  <br> 

  <br>    

</h5>
   
  <button class="button button1 mb-2">Agendar demostración</button>
        <button class="button button2 ml-2 ">Solicitar cotización</button>
 <br>
  <br>

      </div>
    </div>
     
  </div>
</div>

</div>
</template>
<script>
export default {
    name: 'empre_header'
}
</script>
<style scoped>
#parrafoc
{
  font-weight: lighter;
}
.button2
{
margin-bottom:5%
}
</style>