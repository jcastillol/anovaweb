<template>
<div>

      <div class="container mt-4" style="justify-content:center;max-width:400px">
 
    

 <div class="row row-cols-3 bg-transparent no-gutters justify-content-center ">
    <div class="col">
     
           <img src="img/home_facebook.png" class="card-img" alt="..." style="width:40px" >
  
    </div>
      <div class="col ">
      
  <img src="img/home_youtube.png" class="card-img" alt="..." style="width:40px">
        
      </div>
      <div class="col ">

        <img src="img/home_instagram.png" class="card-img" alt="..." style="width:40px">
      </div>
 



      </div>   

       
  
        </div>
             <hr>

  <div class="container" style="max-width:1400px;">
 
     <div class="card mb-3 mx-auto bg-transparent border-0 " >
  <div class="row no-gutters">
    <div class="col-md-3 ">
      <img src="img/logo_anova_gris.png" class="card-img mx-auto  " alt="..." style="width:164px;">
    </div>
    <div class="col-md-8">
      <div class="card-body ml-4">
        <p class="card-text text-left" id="linkf">Somos una empresa de jóvenes emprendedores de Guadalajara, Jalisco con
experiencia en la industria gastronómica que tenemos por objetivo simplificar la
administración y aumentar las utilidades de nuestros clientes a través de
herramientas tecnológicas.
</p>
        <p class="card-text" ></p>
      </div>
    </div>
  </div>
     </div>
<div class="card-group">
 
  <div class="card border-0">
    <div class="card-body ">
     <p class="card-text" id="titulof">MAPA DE SITIO</p>
     <ul class="list-group list-group-flush  ">
    <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">HOME</p></a>
    </li>
    <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">SOFTWARE</p></a>
    </li>
     <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">HARDWARE</p></a>
    </li>
     <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">PRECIOS</p></a>
    </li>
     <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">SOPORTE</p></a>
    </li>
        
  </ul>
    </div>
  </div>

    <div class="card border-0">
    <div class="card-body">
     <p class="card-text" id="titulof">PROXIMOS PASOS</p>
     <ul class="list-group list-group-flush  ">
    <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">DESCARGAR DEMO</p></a>
    </li>
    <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">SOLICITAR SESIÓN DEMO</p></a>
    </li>
     <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">SOLICITAR COTIZACIÓN</p></a>
    </li>
     <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">COMPRAR ANOVA</p></a>
    </li>
  
        
  </ul>
    </div>
  </div>
    <div class="card border-0">
    <div class="card-body">
     <p class="card-text" id="titulof">CONTACTO</p>
     <ul class="list-group list-group-flush  ">
    <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">ISLOTE 2314, COLONIA VALLE VERDE </p></a>
    </li>
    <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf">GUADALAJARA, JALISCO</p></a>
    </li>
     <li class="list-group-item bg-transparent border-0 ">
      <a href="#" ><p class="card-text" id="linkf" style="color: #302CD1"><b>ventas@anova.mx</b></p></a>
    </li>
     
        
  </ul>
    </div>
  </div>

  
</div>
  </div>
  </div>
</template>
<script>
export default {
    name:'footercomp'
}
</script>