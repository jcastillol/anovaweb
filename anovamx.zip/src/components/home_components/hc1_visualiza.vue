<template>
    <div class="container mt-4" style="justify-content:center;" >
  
        <div class="card mb-3 mx-auto bg-transparent border-0 " style="max-width: 1000px;">
  <div class="row no-gutters " >
    <div class="col-md-4 text-center text-md-right">
      <img src="img/home/home_iconografica.png">
    </div>
    <div class="col-md-8">
      <div class="card-body text-center text-md-left">
        <h5   id="tituloa">VISUALIZA LAS FINANZAS</h5>
        <h5  id="titulob">DE TU RESTAURANTE EN TIEMPO REAL</h5>
        <h5   id="tituloc">DASHBOARD WEB</h5>
        <p id="parrafo">Obtén un resumen de las finanzas en tiempo real y visualiza como se
comportan las ventas por día y hora.</p>

      </div>
    </div>
  </div>
</div>
        <div class="card mb-3 mx-auto bg-transparent border-0  " style="max-width: 1000px;">
  <div class="row no-gutters" >
        <div class="col-md-3 order-md-9 text-center text-md-left">
      <img src="img/home/home_iconoalerta.png">
    </div>
       <div class="col-md-9  ">
      <div class="card-body text-center text-md-right">
        <h5   id="tituloa">SUPERVISA TODAS LAS</h5>
        <h5   id="titulob">ENTRADAS Y SALIDAS DE TUS INSUMOS</h5>
        <h5   id="tituloc">CONTROL DE INVENTARIOS</h5>
        <p  id="parrafo">!No te quedes sin producto! ANOVA te avisa cuando es momento de
comprar insumos, gracias a nuestro algoritmo inteligente.</p>
      </div>
     
    </div>
 
   
  </div>
</div>
        <div class="card mb-3 mx-auto bg-transparent border-0 " style="max-width: 1100px;">
  <div class="row no-gutters"  >
    <div class="col-md-4 text-center text-md-right">
      <img src="img/home/home_iconoregistradora.png">
    </div>
    <div class="col-md-8">
      <div class="card-body text-center text-md-left">
        <h5   id="tituloa">VALIDA QUE TODAS LAS</h5>
        <h5  id="titulob">TRANSACCIONES DE CAJA SEÁN CORRECTAS </h5>
        <h5  id="tituloc">CORTE DE CAJA</h5>
        <p id="parrafo">Al final del día registra el dinero que tienes en la caja y ANOVA te dirá si
excede o falta efectivo.</p>

      </div>
    </div>
  </div>
</div>


</div>
</template>

<script>
export default {
    name:'hc1_visualiza'
}
</script>
