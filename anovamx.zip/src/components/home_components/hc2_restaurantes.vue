<template>

 <div class="container-fluid bg-transparent"  id="homerestaurantes"  >
   <div class="container text-center" style="max-width:1400px;">
 <div class="card mb-3 mx-auto bg-transparent border-0 " >
  <div class="row no-gutters">
    <div class="col-md-5 d-none d-lg-block">
      <img src="img/home/home_mujer.png" class="card-img mt-4  " alt="..."  >
    </div>
    <div class="col-lg-7 ">
      <div class="card-body mt-3">
  
      <h5  class=" text-center text-md-right " id="titulohome">Perfecto para </h5>
      <h5  class="text-center text-md-right " id="tituloh"> RESTAURANTES como el tuyo</h5>
       
 <div class="row row-cols-2 row-cols-md-4 bg-transparent no-gutters">
    <div class="col ">
      <div class="card h-100 bg-transparent border-0 ">
        <div class="card-body mx-auto">
          <img src="img/home_bar.png" alt="..." class="mb-1" >
          <p class="card-text text-center" id="tituloc">BAR</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card h-100 bg-transparent border-0">
        <div class="card-body mx-auto">
          <img src="img/home_cafeteria.png" alt="..."  class="mb-1" >
          <p class="card-text" id="tituloc">CAFETERÍA</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card h-100  bg-transparent border-0">
        <div class="card-body mx-auto">
          <img src="img/home_alitas.png" alt="..." class="mb-1" >
          <p class="card-text" id="tituloc">ALITAS</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card h-100 bg-transparent border-0">
        <div class="card-body mx-auto">
          <img src="img/home_foodtruck.png" alt="..." class="mb-1" >
          <p class="card-text" id="tituloc">FOOD TRUCK</p>        </div>
      </div>
    </div>
    <div class="col">
      <div class="card h-100 bg-transparent border-0">
        <div class="card-body mx-auto">
          <img src="img/home_mariscos.png" alt="..."  class="mb-1" >
          <p class="card-text" id="tituloc">MARISCOS</p>        </div>
      </div>
    </div>
    <div class="col ">
      <div class="card h-100 bg-transparent border-0">
        <div class="card-body mx-auto">
          <img src="img/home_taqueria.png" alt="..." class="mb-1" >
          <p class="card-text" id="tituloc">TAQUERÍA</p>        </div>
      </div>
    </div>
    <div class="col  ">
      <div class="card h-100 bg-transparent border-0">
        <div class="card-body mx-auto">
          <img src="img/home_sushi.png" alt="..."  class="mb-1">
          <p class="card-text" id="tituloc">SUSHI</p>
          </div>
      </div>
    </div>
  <div class="col ">
      <div class="card h-100 bg-transparent border-0">
        <div class="card-body mx-auto">
          <img src="img/home_comida_rapida.png" alt="..." class="mb-1" >
          <p class="card-text" id="tituloc">COMIDA RÁPIDA</p>        </div>
      </div>
    </div>
  </div>


       
   
      </div>
    </div>
  </div>
</div>
   </div>
</div>
    
</template>
<script>
export default {
    name: 'home_restaurantes'
}
</script>
<style scoped>
#titulohome
{
    font-size: min(8vw,40px); 

}
</style>