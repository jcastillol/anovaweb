<template>
    <div class="container text-center"  style="max-width:800px;">
  <p class="ml-1" id="tituloe">¿Por qué elegir ANOVA?</p>
  <br>

<div class="row">
  <div class="col-md-6 mt-4">
    <div class="card border-0">
      <img src="img/home/home_iconointeligencia.png" class="mx-auto">
      <div class="card-body mx-auto">
        <h5 class="card-title" id="titulod">DECISIONES INTELIGENTES</h5>
        <p class="card-text" id="parrafob">Detecta oportunidades con la ayuda de nuestro sistema experto y aumenta tus utilidades.</p>
      </div>
    </div>
  </div>
  <div class="col-md-6  mt-4">
    <div class="card border-0">
      <img src="img/home/home_iconocrecimiento.png" class="mx-auto">
      <div class="card-body mx-auto">
        <h5 class="card-title" id="titulod">ACELERA TU CRECIMIENTO</h5>
        <p class="card-text" id="parrafob">Expande tu negocio más rápido automatizando todas las tareas operativas y administrativas.</p>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-6 mt-4">
    <div class="card border-0">
      <img src="img/home/home_iconotiempo.png" class="mx-auto">
      <div class="card-body mx-auto">
        <h5 class="card-title" id="titulod">TIEMPO PARA TI</h5>
        <p class="card-text" id="parrafob">Ya no tendrás que estar todo el tiempo en tu restaurante, deja que tu negocio trabaje para ti.</p>
      </div>
    </div>
  </div>
  <div class="col-md-6  mt-4">
    <div class="card border-0">
      <img src="img/home/home_iconocontrol.png" class="mx-auto">
      <div class="card-body mx-auto">
        <h5 class="card-title" id="titulod">CONTROL TOTAL</h5>
        <p class="card-text" id="parrafob">Detecta oportunidades con la ayuda de nuestro sistema experto y aumenta tus utilidades.</p>
      </div>
    </div>
  </div>
</div>

</div>
</template>
<script>
export default {
    name: 'hc3_porque'
}
</script>