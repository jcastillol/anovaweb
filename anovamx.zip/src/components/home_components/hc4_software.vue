<template>
 <div class="container" id="cardsbutton" style="justify-content:center;max-width:1400px">

<div class="card mb-3 mx-auto bg-transparent border-0 " >
  <div class="row no-gutters">
    <div class="col-md-6 nomovil">
      <img src="img/home/home_ipad.png" class="card-img mt-3 " alt="..." >
    </div>
    <div class="col-md-6">
      <div class="card-body mt-3 text-center text-md-right">
         
      
      <h5   id="tituloa">SOFTWARE INTELIGENTE <br> </h5>
            <h5  id="titulob">EL CEREBRO DE TU RESTAURANTE  </h5>

      <h5   id="tituloc">PODRÁS OPERAR Y ADMINISTRAR <br>
     TODO TU NEGOCIO DESDE UN SOLO LUGAR  </h5> 
         <br>
      <p id="parrafo">Aumenta tus utilidades controlando todas las áreas, 
        realiza las actividades diarias más rápido y automatiza todas las operaciones 
        de tu negocio desde un solo lugar.</p>
  <br>
    <button class="button button2 ml-2">Ver mas información</button>


      </div>
    </div>
  </div>
</div>


<div class="card mb-3 mx-auto bg-transparent border-0 " >
  <div class="row no-gutters">
   <div class="col-md-7 order-md-5 nomovil">
      <img src="img/home/home_paqueteequipo.png" class="card-img mt-3 " alt="..." >
    </div>
    <div class="col-md-5">
      <div class="card-body mt-3 text-center text-md-left">
         
      
      <h5   id="tituloa">EQUIPO DE PUNTO DE VENTA</h5>
      <h5  id="titulob">TE OFRECEMOS LA SOLUCIÓN <br>COMPLETA AL MEJOR COSTO  </h5>
            <h5  class="card-title text-left" id="titulob"></h5>
 
      <h5   id="tituloc">UNICAMENTE CONECTALO <br> Y DISFRUTA LOS BENEFICIOS</h5>
<br>
      <p id="parrafo">Nosotros configuramos todo el equipo de punto de venta, incluidas
computadoras, impresoras, tablets y otros dispositivos, además te lo
entregamos listo para usar.</p>
 <br>
    <button class="button button2 ml-2 ">Ir a tienda ANOVA</button>


      </div>
    </div>
     
  </div>
</div>


</div>    
</template>
<script>
export default {
    name: 'hc4_software'
}
</script>
