<template>
    <div class="container text-center"  id="soporte" style="max-width:800px;">
  <p  id="tituloe">Asistencia y Soporte Técnico</p>
  <h5 id="tituloc">PODRAS OPERAR Y ADMINISTRAR TODO TU NEGOCIO</h5>
<h5  id="tituloc"> ADMINISTRAR TODO TU NEGOCIO</h5>

     <img src="img/home/home_ilustracionteam.png" class="card-img nomovil" alt="" srcset="">

    <p class="card-text text-center" id="parrafo">Un equipo de expertos ANOVA está para ayudarte a resolver cualquier duda 
y darte soporte  en la operación  y administración de tu restaurante.  </p>

    <button class="button button2 ml-2">Ir a Soporte</button>

</div>
</template>
<script>
export default {
    name: 'hc5_soporte'
}
</script>