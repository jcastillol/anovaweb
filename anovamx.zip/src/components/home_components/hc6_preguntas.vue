<template>
    <div>
 <div class="container text-center"  id="clientes" style="max-width:1200px;">
  <p  id="tituloe">¿Qué dicen nuestros clientes?</p>
  <br>
<h5 id="tituloc">RECOMENDADO POR LOS EXPERTOS EN</h5>
<h5  id="tituloc"> ADMINISTRACIÓN DE RESTAURANTES</h5>
<br>
<div class="card-deck">
  <div class="card ">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card d-lg-block d-none">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
</div>

</div>
<br>
<br>
<br>

<br>
<div class="container text-center"  style="max-width:1200px">


  <div class="row row-cols-2 row-cols-lg-5 bg-transparent no-gutters justify-content-center ">
    <div class="col">
     
           <img src="img/home_wingman.png" class="mx-auto mb-4" >
  
    </div>
      <div class="col ">
      
                <img src="img/home_maschurro.png"  class="mx-auto mb-4">
        
      </div>
      <div class="col ">

        <img src="img/home_lamezcalita.png" class="mx-auto mb-4">
      </div>
 
 <div class="col ">

                <img src="img/home_bones.png" class="mx-auto mb-4">
      </div>

      <div class="col ">

                <img src="img/home_hampton.png" class="mx-auto mb-4" >
      </div>

    


      </div>   


  




</div>
    </div>
</template>
<script>
export default {
    name: 'hc6_preguntas'
}
</script>