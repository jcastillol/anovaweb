<template>
    
    <div class="container mt-4 text-center" style="max-width:1200px;">
  <p  id="tituloe">Ten todos los procesos <br> de tu restaurante bajo control</p>
 
  <br>
            <button class="button button2 ml-2">
         <router-link :to="'Prueba_30dias'" id="link2">Descargar demo</router-link>

               </button>

 
</div>
</template>
<script>
export default {
    name: 'hc7_procesos'
}
</script>