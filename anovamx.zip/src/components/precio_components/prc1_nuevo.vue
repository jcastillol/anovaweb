<template>
     <div class="container bg-transparent"  id="precios" style="max-width:1400px;" >
<div class="card mb-5 mx-auto bg-transparent border-0  "  >
  <div class="row ">
    <div class="col-xl-7">
      <img src="img/precios/pantalla_modulo.png" class="card-img  " >
    </div>
    <div class="col-xl-5">
      <div class="card-body mt-3 bg-transparent text-center ">
      <h5   id="tituloj">¡  N  U  E  V  O  !</h5>
       <h5  id="parrafod">AHORA PUEDES REALIZAR TUS FACTURAS</h5>
<p  id="tituloe">MÓDULO DE </p>
<p  id="tituloe2">FACTURACIÓN CFDI 3.3</p>

<p  id="parrafo">Paquete de 25 facturas al mes no acumulables</p>
<p  id="tituloc">$150 MXN MENSUALES</p>


    <button class="button button2 ">Compra ahora</button>



      </div>
    </div>
  </div>
</div>
   
     </div>
</template>
<script>
export default {
    name: 'prc1_nuevo'
}
</script>