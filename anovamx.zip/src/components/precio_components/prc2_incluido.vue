<template>
  <div class="container text-center" id="cardsdeck" style="max-width:1000px;">
    <p class="ml-1" id="tituloe">Incluido en ambos planes</p>
    <br />

    <div class="row mb-5">
      <div class="col-sm-6">
        <div class="card border-0">
          <img src="img/precios/icono1.png" class="mx-auto" alt="..." />
          <div class="card-body mx-auto">
            <h5 class="card-title" id="titulod">SOPORTE TÉCNICO</h5>
            <p class="card-text" id="parrafob">
              Comunícate con un experto ANOVA y con gusto te asesoramos en
              cualquier duda o problema que tengas.
            </p>
          </div>
        </div>
      </div>
      <div class="col-sm-6">
        <div class="card border-0">
          <img src="img/precios/icono2.png" class="mx-auto" alt="..." />
          <div class="card-body mx-auto">
            <h5 class="card-title" id="titulod">MANUALES DE CAPACITACIÓN Y TUTORIALES</h5>
            <p class="card-text" id="parrafob">
              Sabemos que tienes poco tiempo libre por ello desarrollamos manuales
              fáciles y prácticos para que configures ANOVA el mismo día.
            </p>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-sm-6">
        <div class="card border-0 mt-3">
          <img src="img/precios/icono3.png" class="mx-auto" alt="..." />
          <div class="card-body mx-auto">
            <h5 class="card-title" id="titulod">ASESORÍA PERSONALIZADA</h5>
            <p class="card-text" id="parrafob">
              Un asesor te ayudará a escoger el equipo de punto de venta adecuado , o
              si ya tienes equipo te decimos como utilizarlo.
            </p>
          </div>
        </div>
      </div>

      <div class="col-sm-6">
        <div class="card border-0 mt-3">
          <img src="img/precios/icono4.png" class="mx-auto" alt="..." />
          <div class="card-body mx-auto">
            <h5 class="card-title" id="titulod">INTEGRACIÓN CON IPADS Y TABLETS</h5>
            <p class="card-text" id="parrafob">
              ANOVA es compatible con tabletas y ipads, por lo que tus meseros
              podrán tomar la orden desde la mesa y agilizar más el servicio.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "prc2_incluido"
};
</script>