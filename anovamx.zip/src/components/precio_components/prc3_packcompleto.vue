<template>
    <div class="container text-center" id="packcompleto" >
 <br>
  <br>

  <p  id="tituloi">COTIZA TU PAQUETE COMPLETO</p>
<div class="card  bg-transparent border-0" >
  <ul class="list-group bg-transparent list-group-flush">
    <li class="list-group-item border-0 bg-transparent "> 
      <img src="img/precios/preciopv_solucioncompleta.png"  class="card-img"  style="max-width:786px">
</li>
    <li class="list-group-item border-0 bg-transparent ">
     
    <h5  id="titulok">EQUIPO A TU MEDIDA</h5>
<p class="parrafoc">Si estás aperturando tu restaurante  y necesitas todo el equipo, o si solo <br>
necesitas complementar el que ya tienes, ANOVA tiene la solución a tu medida.

</p>

    <button class="button button2 ml-2">Cotizar hoy</button>

<br>
 <br>
 <br>

    </li>
    
  </ul>
</div>

</div>

</template>
<script>
export default {
    name: 'pc5_tuinfo'
}
</script>