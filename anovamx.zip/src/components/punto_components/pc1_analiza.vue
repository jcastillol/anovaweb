<template>
 <div class="container " style="justify-content:center;max-width:1400px">
  
  <p  id="tituloe">ANALIZA </p>
  <p  id="tituloe">TUS TENDENCIAS</p>
<br>
<br>
<div class="card mb-5 mx-auto bg-transparent border-0 ">
  <div class="row ">
     <div class="col-md-7 order-md-5">
      <img src="img/punto/pv_dashboardgerencial.png" class="card-img"  style="max-width:765px">
    </div>
    <div class="col-md-5  " >
      <div class="card-body text-center text-md-right">
      <h5   id="tituloa3">COMPARA</h5>
            <h5   id="titulob">TUS METRICAS</h5>
      <h5   id="tituloc">DASHBOARD GERENCIAL</h5>
      <p class="card-text" id="parrafo">
       Obtén resumen de las finanzas de su restaurante
en tiempo real y visualiza cómo se comportan
las ventas por día de la semana y horas del día.
        </p>

      </div>
    </div>
    
  </div>
</div>
<br>
<br>
<br>

<div class="card mb-5 mx-auto bg-transparent border-0 ">
  <div class="row ">
    <div class="col-md-7 ">
      <img src="img/punto/pv_asistentedeinventarios.png"   class="card-img"  style="max-width:765px" >
    </div>
    <div class="col-md-5  " >
      <div class="card-body text-center text-md-left">
      <h5    id="tituloa3">CONTROLA</h5>
            <h5  id="titulob">TUS INSUMOS</h5>
      <h5   id="tituloc">ASISTENTE DE INVENTARIOS</h5>
      <p id="parrafo">
        ¡No te quedes sin producto ! ANOVA te avisa cuando 
        es buen momento para comprar insumos, gracias a 
        nuestro algoritmo inteligente.
      </p>
      </div>
    </div>
     
  </div>
</div>


</div>    

</template>
<script>
export default {
    name:'pc1_analiza'
}
</script>
