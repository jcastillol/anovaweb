<template>
 <div class="container" style="justify-content:center;max-width:1400px">
  
  <p  id="tituloe">PROTEGE LA SEGURIDAD<br>
DE TU RESTAURANTE </p>
 
<br>
<br>
<div class="card mb-5 mx-auto bg-transparent border-0 ">
  <div class="row ">
      <div class="col-md-7 order-md-5" >
      <img src="img/punto/pv_perfilesdeusuarios.png" class="card-img" width="765px"  >
    </div>
    <div class="col-md-5  " >
      <div class="card-body text-center text-md-right">
      <h5   id="tituloa3">SEGURIDAD </h5>
            <h5   id="titulob">EN TU NEGOCIO</h5>
      <h5  id="tituloc">PERFILES DE USUARIOS</h5>
      <p  id="parrafo">
        Asigna permisos y restricciones a las personas 
que utilizaran el sistema, puedes crear perfiles como
gerente, capitán de meseros, mesero y personalizarlos.
        </p>

      </div>
    </div>
   
  </div>
</div>
<br>
<br>
<br>

<div class="card mb-5 mx-auto bg-transparent border-0 ">
  <div class="row ">
    <div class="col-md-7">
      <img src="img/punto/pv_cortedecaja.png"  class="card-img" width="765px" >
    </div>
    <div class="col-md-5  " >
      <div class="card-body text-center text-md-left">
      <h5   id="tituloa3">QUE NUNCA</h5>
            <h5  id="titulob">TE FALTE DINERO</h5>
      <h5   id="tituloc">CORTE DE CAJA</h5>
      <p  id="parrafo">
       Al final del día registra el dinero que tienes en 
la caja y ANOVA te dirá si excede o falta efectivo.
      </p>
      </div>
    </div>
     
  </div>
</div>


</div>    

</template>
<script>
export default {
    name:'pc2_protege'
}
</script>
<style scoped>
 #tituloa{
   margin-top: 30%;
 }
</style>