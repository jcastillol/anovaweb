<template>
 <div class="container" style="justify-content:center;max-width:1400px">
  
  <p  id="tituloe">AGILIZA LOS PROCESOS<br>
DE TUS ÁREAS </p>
 
<br>
<br>
<div class="card mb-5 mx-auto bg-transparent border-0 ">
  <div class="row ">
     <div class="col-md-7 order-md-5">
      <img src="img/punto/pv_mapademesas.png" class="card-img" width="765px"  >
    </div>
    <div class="col-md-5  " >
      <div class="card-body text-center text-md-right">
      <h5    id="tituloa3">AGILIZA </h5>
            <h5   id="titulob">TU SERVICIO</h5>
      <h5  id="tituloc">MAPA DE MESAS</h5>
      <p id="parrafo">
       Toda la información de tus mesas en una sola pantalla,
optimizada para hacer todas las operaciones más rápidas, 
desde dividir una mesa hasta pagar una cuenta.
        </p>

      </div>
    </div>
    
  </div>
</div>
<br>
<br>
<br>

<div class="card mb-5 mx-auto bg-transparent border-0 ">
  <div class="row ">
    <div class="col-md-7">
      <img src="img/punto/pv_cortedecaja.png" class="card-img"  width="765px" >
    </div>
    <div class="col-md-5  " >
      <div class="card-body text-center text-md-left">
      <h5   id="tituloa3">PERSONALIZA</h5>
            <h5   id="titulob">TUS COMANDAS</h5>
      <h5   id="tituloc">COMANDERO RAPIDO</h5>
      <p  id="parrafo">
     Selecciona los platillos y bebidas que piden tus 
comensales para que se impriman inmediatamente 
en la barra y la cocina.
Agrupa tus productos por familias y categorías.

      </p>
      </div>
    </div>
     
  </div>
</div>


</div>    

</template>
<script>
export default {
    name:'pc3_agiliza'
}
</script>
<style scoped>
 #tituloa{
   margin-top: 30%;
 }
</style>