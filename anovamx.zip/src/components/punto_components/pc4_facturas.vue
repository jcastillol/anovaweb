<template>
     <div class="container text-center"   style="max-width:1000px;">
  <p  id="tituloe">MANDA FACTURAS A <br>
  TUS CLIENTES </p>
 


<div class="card border-0" >

      <img src="img/punto/pv_laptopfacturas.png" class="imgfactura card-img" >

      <h5  id="tituloa">COMPLETA AL MEJOR COSTO </h5>
      <h5  id="titulob">ÚNICAMENTE CONECTALO</h5>
      <br>
    <h5   id="tituloc">MÓDULO DE FACTURACIÓN CFDI 3.3</h5>
    <br>
        <h1 id="parrafo">Atiende los requerimientos establecidos por el SAT, obteniendo 
comprobantes fiscales digitales con un certificado de firma electrónica avanzada.</h1>

</div>

</div>
</template>
<script>
export default {
    name:'pc4_facturas'
}
</script>
<style scoped>
.imgfactura
{
  margin-right:15%

}
</style>
