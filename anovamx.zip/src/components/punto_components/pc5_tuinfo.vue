<template>
     <div class="container bg-transparent text-center"  id="tuinfo"  >
 <br>
  <br>

  <h5  id="tituloi">TU INFORMACIÓN EN UN </h5>
  <h5 id="tituloj">SOLO LUGAR Y TIEMPO REAL</h5>

 <br>

      <img src="img/punto/pv_dashboardweb.png"  alt="..." class="card-img" style="max-width:640px">
     
    <h5  id="titulok">DASHBOARD WEB</h5>
     <p id="parrafoc"> 
       Accede a toda tu información en cualquier momento, en cualquier lugar, con este módulo<br>
de inteligencia de negocios, con reportes que te ayudan a la toma de decisiones acertadas.

     </p>

<br>
<br>
<br>
</div>

</template>
<script>
export default {
    name: 'pc5_tuinfo'
}
</script>