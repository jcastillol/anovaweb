<template>
     <div class="container bg-transparent text-center"  style="max-width:1200px;" >
 <div class="row row-cols-1 row-cols-md-3 bg-transparent no-gutters justify-content-center ">
    <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body">
      <img src="img/punto/pv_iconomapa.png" class="card-img imagenpunto mb-2" alt="..."  >
          <h5  id="titulod">REPORTES <br>
MULTISUCURSAL</h5>
        <p  id="parrafob">
          Visualiza y compara con gráficos el rendimiento de todas tus 
sucursales o franquicias.
        </p>    
        </div>
      </div>
    </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body">
      <img src="img/punto/pv_iconomultidispositivo.png" class="card-img imagenpunto mb-2"  alt="..." />
       <h5  id="titulod">ACCESO<br>
MULTIDISPOSITIVO</h5>
        <p id="parrafob">
           Accede a toda tu información desde cualquier dispositivo con acceso a 
internet en tiempo real.
           </p>       
        </div>
      </div>
      </div>
      <div class="col ">
      <div class="card  bg-transparent border-0 ">
        <div class="card-body">
      <img src="img/punto/pv_iconografica.png" class="card-img imagenpunto mb-2" alt="..." >
          <h5  id="titulod">DASHBOARD<br>
INTELIGENTE</h5>
        <p id="parrafob">
          Optimiza tu  potencial con el panel de reportes que analiza tus datos y te da 
recomendaciones.
        </p>       
       </div>
      </div>
      </div>   


   </div>  
    
     </div>
</template>
<script>
export default {
    name: 'pc6_reportes'
}
</script>