<template>
 <div class="container mt-4 text-center"   style="max-width:1200px;">
  <p id="tituloe">Mejora la experiencia de tus clientes<br>y aumenta tus ganancias </p>
  <br>
        <button class="button button2 ml-2">Descarga demo</button>

 
</div>
</template>
<script>
export default {
    name: 'pc7_mejora'
}
</script>