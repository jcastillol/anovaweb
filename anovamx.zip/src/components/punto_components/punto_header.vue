<template>
<div class="container-fluid" id="puntoheader">
<div class="card mb-3 mx-auto bg-transparent border-0 " style="max-width:1400px" >
  <div class="row no-gutters">
   <div class="col-md-6 nomovil ">
      <img src="img/punto/pv_laptop.png" class="card-img puntoimg  " >
    </div>
    <div class="col-lg-6">
                     <div class="card-body  text-center text-lg-right bg-transparent ">

      <h5  id="titulohome">ANOVA Punto de venta</h5>
 <br>
      <h5   id="parrafoc">
                <img src="img/play.png" >
Dejános a nosotros la administración </h5>
            <h5  id="parrafoc">y  dedícale mas tiempo a tus clientes</h5>
<br>
    <button class="button button1 mb-2 ml-2">Descargar demo</button>
        <button class="button button2 ml-2">Precios</button>
 <div class="text-center nomovil">
      <img src="img/punto/pv_cerebro.png" class="card-img" style="max-width:300px" >
 

 </div>

      </div>
    </div>
  </div>
  </div>
  </div>
</template>
<script>
export default {
    name: 'punto_header'
}
</script>
<style scoped>
.puntoimg
{
  margin-top: 20%;
}
#titulohome
{
    margin-top: 10%;

}
#parrafoc
{
  font-weight: lighter;
}
</style>