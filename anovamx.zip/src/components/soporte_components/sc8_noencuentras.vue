<template>
    <div class="container text-center" style="max-width:1000px">
      <h5 id="tituloe">¿No encuentras lo que necesitas?</h5>
      <br>
      <br>
      <img src="img/soporte/soporte_iconosoporte.png" alt="" srcset="">
      <br>
      <br>
      <p id="parrafoc">
          Si tienes preguntas muy especificas o necesitas reportar un problema puedes
comunicarte con un experto que te atenderá personalmente y resolverá tus dudas.


      </p>
              <br />
        <br />
      <p id="tituloc">Mándanos Whatsapp al  </p> 
     <p id="tituloa">33 17 28 44 97 </p> 

      <br>
      <br>
    </div>
</template>