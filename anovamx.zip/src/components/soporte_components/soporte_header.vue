<template>
<div class="container-fluid" id="soporteheader">
    <div class="container text-center" style="max-width:1400px">
         <h5  id="titulohome">         
             <img src="img/play.png" >
            Centro de soporte ANOVA
         </h5>
         <p class="parrafoc"> 
           Tal vez tengas dudas acerca del software y el equipo,<br>
en esta sección encontraras información que te serán de gran ayuda
<br>
<br>
<br>
         </p>
    </div>
</div>
</template>
<script>
export default {
    name: 'soporte_header'
}
</script>
<style scoped>
#titulohome
{
    margin-top: 5%;
}


</style>